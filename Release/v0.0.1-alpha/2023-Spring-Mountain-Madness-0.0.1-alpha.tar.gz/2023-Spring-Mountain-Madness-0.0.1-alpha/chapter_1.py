def branch1(name):
    print("Welcome to the first branch of the game " + name + "!")



