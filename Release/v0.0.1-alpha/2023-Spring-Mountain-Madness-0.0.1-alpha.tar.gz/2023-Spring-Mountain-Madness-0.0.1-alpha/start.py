#this is for starting the game

open("data.csv", "rw")


print("Hello traveller, weclome to Paris!")
print("What is your name?")

name = input()

print("Hello " + name + ", it is a pleasure to meet you!")
print("Your mission is to find the treasure in the city of Paris.")
print("You will be given a series of clues to help you find the treasure.")